﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROG7312_POE_Part1_Wpf
{
    /*internal*/ public class AreasDictBackup
    {/*
        IDictionary<string, string> QandA = new Dictionary<string, string>();
        static void Dic()
        {
            //Method
            IDictionary<string, string> QandA = new Dictionary<string, string>();
            QandA.Add("What is this called 000–099?", "general works"); ; //adding a key/value using the Add() method
            QandA.Add("What is this called 100–199?", "philosophy and psychology");
            QandA.Add("What is this called 200–299?", "religion");
            QandA.Add("What is this called 300–399?", "social sciences");
            QandA.Add("What is this called 400–499?", "language");
            QandA.Add("What is this called 500–599?", "natural sciences and mathematics");
            QandA.Add("What is this called 600–699?", "technology");
            QandA.Add("What is this called 700–799?", "the arts");
            QandA.Add("What is this called 800–899?", "literature and rhetoric");
            QandA.Add("What is this called 900–999?", "history, biography, and geography");
        }*/
    }
}
