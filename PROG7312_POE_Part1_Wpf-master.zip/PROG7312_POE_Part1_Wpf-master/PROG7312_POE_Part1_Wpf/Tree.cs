﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//POE Part 3 Tree system
//First part of Tree system, (uses 'TreeNode' and '')

namespace PROG7312_POE_Part1_Wpf
{
    /*internal*/ class Tree<T>
    {
        public TreeNode<T> Root { get; set; }
        /*static void Main(string[] args)
        {
            CGraph pleasework = new CGraph();
            pleasework.addNode(1, "Nicole");
            pleasework.addNode(2, "Luke");
            pleasework.addNode(3, "Stefan");

            bool yes = pleasework.hasPathDFS(1, 3);
            if (yes)
            {
                Console.WriteLine("Nicole is related to Stefan m they can be cousins");
            }
            else
            {
                Console.WriteLine("NOOOOOOOOOOOOOOO :)");
            }

            bool BFSYes = pleasework.hasPathBFS(2, 3);
            if (BFSYes)
            {
                Console.WriteLine("BFS PATH FOUND between Nocole and Stefan");
            }
            else
            {
                Console.WriteLine("Noo");
            }
        }*/
    }
}
