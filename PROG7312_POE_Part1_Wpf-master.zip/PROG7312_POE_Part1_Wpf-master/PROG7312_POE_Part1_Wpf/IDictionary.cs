﻿namespace PROG7312_POE_Part1_Wpf
{
    internal interface IDictionary<T1, T2, T3>
    {
    }
}