﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Web;

namespace PROG7312_POE_Part1_Wpf
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        

        private void btnreplacepage_Click(object sender, RoutedEventArgs e)//'ReplacePage'
        {
            ReplacePage replacePage = new ReplacePage();    
            this.Hide();
            replacePage.Show();
        }

        private void button2_Click(object sender, RoutedEventArgs e)//'Achievements' Page
        {
            Achievements achievements = new Achievements();
            this.Hide();
            achievements.Show();
        }

        private void button_Click(object sender, RoutedEventArgs e)//'Indentifying areas' Page
        {
            Identifyingareas indentifyingareas = new Identifyingareas();
            this.Hide();
            indentifyingareas.Show();
        }

        private void button1_Click(object sender, RoutedEventArgs e)//'Finding call numbers' Page (will be added soon)
        {
            /*Identifyingareas findingcallnumbers = new findingcallnumbers();
            this.Hide();
            findingcallnumbers.Show();*/
            Findcallnumbers findcallnumbers = new Findcallnumbers();
            this.Hide();
            findcallnumbers.Show();
        }
        //
        /*private void button_Click(object sender, RoutedEventArgs e)//'Finding call numbers' Page
        {
            Identifyingareas indentifyingareas = new Identifyingareas();
            this.Hide();
            indentifyingareas.Show();
        }*/
    }
}
