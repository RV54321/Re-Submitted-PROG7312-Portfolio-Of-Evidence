﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROG7312_POE_Part1_Wpf
{
    public/*private*/ class SharedDataClass : INotifyPropertyChanged
    {
        public/*private*/ static string sharedValue;//Made string 'static' 

        public string SharedValue
        {
            get { return sharedValue; }
            set
            {
                if (sharedValue != value)
                {
                    sharedValue = value;
                    OnPropertyChanged(nameof(SharedValue));
                }
            }
        }
        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
