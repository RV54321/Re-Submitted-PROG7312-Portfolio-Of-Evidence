﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PROG7312_POE_Part1_Wpf
{
    /// <summary>
    /// Interaction logic for Findcallnumbers.xaml
    /// </summary>
    public partial class Findcallnumbers : Window
    {
        public Findcallnumbers()
        {
            InitializeComponent();
        }
        //Tree System
        private void Form1_Load(object sender, EventArgs e)
        {
            //Tree <int/*, string*/> tree = new Tree<int>();
            //tree.Root = new TreeNode<int>() { Data = 000/*, Description = 'Description'*/ };//Call Numbers and Description

            Tree<string> tree = new Tree<string>();
            tree.Root = new TreeNode<string>() { Data = "000 - Computer Science, Information, and General Works (First Level)"/*, Description = 'Description'*/ };//Call Numbers and Description

            tree.Root.Children = new List<TreeNode<string>>
            {
                //new TreeNode<int>() { Data = 000, Parent = tree.Root},//Computer Science, Information, and General Works

                new TreeNode<string>() { Data = "000", Parent = tree.Root},//Computer Science, Information, and General Works
                new TreeNode<string>() { Data = "100", Parent = tree.Root },//Philosophy and Psychology
                new TreeNode<string>() { Data = "200", Parent = tree.Root },//Religion
                new TreeNode<string>() { Data = "300", Parent = tree.Root }//Social Sciences
            };
            //'000 - Computer Science, Information, and General Works (First Level)'
            tree.Root.Children[0].Children = new List<TreeNode<string>>()
            {
                new TreeNode<string>() {Data = "000 Computer science, knowledge & systems", Parent = tree.Root.Children[0] },//'Computer science, knowledge & systems'
                new TreeNode<string>() {Data = "010 Bibliographies (Third Level)", Parent = tree.Root.Children[0] },//'Bibliographies (Third Level)'
                new TreeNode<string>() {Data = "020 Library & information sciences", Parent = tree.Root.Children[0] },//'Library & information sciences'
                new TreeNode<string>() {Data = "030 Encyclopedias & books of facts", Parent = tree.Root.Children[0] },//'Encyclopedias & books of facts'
                new TreeNode<string>() {Data = "040 [Unassigned]", Parent = tree.Root.Children[0] },//'[Unassigned]'
                new TreeNode<string>() {Data = "050 Magazines, journals & serials", Parent = tree.Root.Children[0] },//'Magazines, journals & serials'
                new TreeNode<string>() {Data = "060 Associations, organizations & museums", Parent = tree.Root.Children[0] },//'Associations, organizations & museums'
                new TreeNode<string>() {Data = "070 News media, journalism & publishing", Parent = tree.Root.Children[0] },//'News media, journalism & publishing'
                new TreeNode<string>() {Data = "080 Quotations", Parent = tree.Root.Children[0] }//'Quotations'
            };
            //'100 - Philosophy and Psychology'
            tree.Root.Children[1].Children = new List<TreeNode<string>>()
            {
                new TreeNode<string>() {Data = "100 Philosophy", Parent = tree.Root.Children[1] },//'Philosophy'
                new TreeNode<string>() {Data = "110 Metaphysics", Parent = tree.Root.Children[1] },//'Metaphysics'
                new TreeNode<string>() {Data = "120 Epistemology", Parent = tree.Root.Children[1] },//'Epistemology'
                new TreeNode<string>() {Data = "130 Parapsychology & occultism", Parent = tree.Root.Children[1] },//'Parapsychology & occultism'
                new TreeNode<string>() {Data = "140 Philosophical schools of thought", Parent = tree.Root.Children[1] },//'Philosophical schools of thought'
                new TreeNode<string>() {Data = "150 Psychology", Parent = tree.Root.Children[1] },//'Psychology'
                new TreeNode<string>() {Data = "160 Logic", Parent = tree.Root.Children[1] },//'Logic'
                new TreeNode<string>() {Data = "170 Ethics", Parent = tree.Root.Children[1] },//'Ethics'
                new TreeNode<string>() {Data = "180 Ancient, medieval & eastern philosophy", Parent = tree.Root.Children[1] },//'Ancient, medieval & eastern philosophy'
                new TreeNode<string>() {Data = "190 Modern western philosophy", Parent = tree.Root.Children[0] }//'Modern western philosophy'
            };
            //'200 - Religion'
            tree.Root.Children[2].Children = new List<TreeNode<string>>()
            {
                new TreeNode<string>() {Data = "200 Religion", Parent = tree.Root.Children[0] },//'Religion'
                new TreeNode<string>() {Data = "210 Philosophy & theory of religion", Parent = tree.Root.Children[0] },//'Philosophy & theory of religion'
                new TreeNode<string>() {Data = "220 The Bible", Parent = tree.Root.Children[0] },//'The Bible'
                new TreeNode<string>() {Data = "230 Christianity & Christian theology", Parent = tree.Root.Children[0] },//'Christianity & Christian theology'
                new TreeNode<string>() {Data = "240 Christian practice & observance", Parent = tree.Root.Children[0] },//'Christian practice & observance'
                new TreeNode<string>() {Data = "250 Christian pastoral practice & religious orders", Parent = tree.Root.Children[0] },//'Christian pastoral practice & religious orders'
                new TreeNode<string>() {Data = "260 Christian organization, social work & worship", Parent = tree.Root.Children[0] },//'Christian organization, social work & worship'
                new TreeNode<string>() {Data = "270 History of Christianity", Parent = tree.Root.Children[0] },//'History of Christianity'
                new TreeNode<string>() {Data = "280 Christian denominations", Parent = tree.Root.Children[0] },//'Christian denominations'
                new TreeNode<string>() {Data = "290 Other religions", Parent = tree.Root.Children[0] }//'Other religions'
            };
            //'300 - Social Sciences'
            tree.Root.Children[3].Children = new List<TreeNode<string>>()
            {
                new TreeNode<string>() {Data = "300 Social sciences, sociology & anthropology", Parent = tree.Root.Children[0] },//'Social sciences, sociology & anthropology'
                new TreeNode<string>() {Data = "310 Statistics", Parent = tree.Root.Children[0] },//'Statistics'
                new TreeNode<string>() {Data = "320 Political science", Parent = tree.Root.Children[0] }//'Political science'
            };
            //
            //lblOutput.Text = lblOutput.Text + "" + tree.Root.Children[3].Data.ToString();
            //tree.Root.Children[2].Children.Add(new TreeNode<int>() { Data = 40, Parent = tree.Root.Children[2] });
            //PrintAll(tree);
        }
        private void btnachieve_Click(object sender, RoutedEventArgs e)//Achievment Page Button
        {
            Achievements achievements = new Achievements();
            this.Hide();
            achievements.Show();
        }

        private void button_Click(object sender, RoutedEventArgs e)//Back Button
        {
            MainWindow mainWindow = new MainWindow();
            this.Hide();
            mainWindow.Show();
        }
    }
}
