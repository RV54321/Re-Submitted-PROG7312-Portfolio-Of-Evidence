﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Reflection.Metadata;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
//using static PROG7312_POE_Part1_Wpf.GFG;//added
using static PROG7312_POE_Part1_Wpf.Node;//added
using static System.Runtime.InteropServices.JavaScript.JSType;
//When the user selects Replacing books,
//the application shall randomly generate 10 different call numbers, and display them to the user.
//Make use of a list to store the generated call numbers.
//Keeps crashing, must fix
namespace PROG7312_POE_Part1_Wpf
{
    internal class Linkedlist
    {
        static void LinkedMain(string[] args)//Changed Main to LinkedMain
        //Random random = new Random();//initialized it
        {
            //Blob blobGen = new Blob();
            //Random random = new Random();//initialized it

            //For loop attempt
            for (int i = 0; i < 9; i++)
            {
                Blob blobGen = new Blob();
                Random random = new Random();//initialized it
                blobGen.Add(random.Next(0, 1000),"JAM");
                Node head = blobGen.Head;
                /*//Trying to fill textboxes on ReplacePage so they can be used
                txtcall1.Text = 10.ToString();
                txtcall2.Text = 9.ToString();
                txtcall3.Text = 8.ToString();
                txtcall4.Text = 7.ToString();
                txtcall5.Text = 6.ToString();
                txtcall6.Text = 5.ToString();
                txtcall7.Text = 4.ToString();
                txtcall8.Text = 3.ToString();
                txtcall9.Text = 2.ToString();
                txtcall10.Text = 1.ToString();*/
            }
            /*blobGen.Add("000,000 ", "JAM");//blobGen.Add(0);
            blobGen.Add(random.Next(0, 1000));
            blobGen.Add(random.Next(0, 1000));
            blobGen.Add("000,000 ", "JAM");
            blobGen.Add("000,000 ", "JAM");
            blobGen.Add("000,000 ", "JAM");
            blobGen.Add("000,000 ", "JAM");
            blobGen.Add("000,000 ", "JAM");
            blobGen.Add("000,000 ", "JAM");
            blobGen.Add("000,000 ", "JAM");
            Node head = blobGen.Head;
            Console.WriteLine("Size of the list is {0}", countNode(head));//*/
        }
        public static int countNode(Node Head)
        {
            int count = 1;
            Node current = Head;
            while (current.next != null)
            {
                current = current.next;
                count++;
            }
            return count;
        }
        public static Node GetFirst(Node Middle)
        {
            Node first = Middle;
            while (first.prev != null)//changed previous to prev
            {
                first = first.prev;//changed previous to prev
            }
            return first;
        }
        public static Node AddNode(Node Add, Node Current)
        {
            Add.prev = Current;//changed previous to prev
            Add.next = Current.next;
            Current.next = Add;
            return Current;
        }
        //Print out whole list, must send to textboxes somehow
        public static void PrintAll(Node Head)
        {
            Node currrent = GetFirst(Head);
            while (currrent != null)
            {
                Console.Write(currrent.data + " ");//changed value to data
                currrent = currrent.next;
            }
            Console.WriteLine();
        }//*/
    }
}
