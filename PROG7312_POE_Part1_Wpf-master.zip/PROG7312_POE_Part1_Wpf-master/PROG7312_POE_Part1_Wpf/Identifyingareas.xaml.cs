﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
//using PROG7312_POE_Part1_Wpf.AreasDictionary;
//ONLY SUBMIT THIS COPY OF THE WORK SPECIFICALLY!!!

namespace PROG7312_POE_Part1_Wpf
{
    /// <summary>
    /// Interaction logic for Identifyingareas.xaml
    /// </summary>
    public partial class Identifyingareas : Window
    {
        //Answer Variables
        public string a1;
        public string a2;
        public string a3;
        public string a4;
        //Dictionary
        public static IDictionary<string, string> QandA =new Dictionary<string, string>();
        static void /*Main*/ Dic(/*string[] args*/)
        {
            //Method
            QandA.Add("What is this called 000–099?", "general works"); //Adding a key/value using the Add() method(s)
            QandA.Add("What is this called 100–199?", "philosophy and psychology");
            QandA.Add("What is this called 200–299?", "religion");
            QandA.Add("What is this called 300–399?", "social sciences");
            QandA.Add("What is this called 400–499?", "language");
            QandA.Add("What is this called 500–599?", "natural sciences and mathematics");
            QandA.Add("What is this called 600–699?", "technology");
            QandA.Add("What is this called 700–799?", "the arts");
            QandA.Add("What is this called 800–899?", "literature and rhetoric");
            QandA.Add("What is this called 900–999?", "history, biography, and geography");
        }

        public Identifyingareas()
        {
            InitializeComponent();
            Dic();
            //btntryagain_Click();
        }

        private void button_Click(object sender, RoutedEventArgs e)//Back Button
        {
            MainWindow mainWindow = new MainWindow();
            this.Hide();
            mainWindow.Show();
        }
        public void FillQuestionTextboxes() //Question textboxes
        {
            //Autofill data with questions from dictionary, Numbers(Question) = Key
            Random randNum = new Random();
            //randNum.Next(min, max)
            //Dictionary<string, object> QandAvalues = GetDictionary();//dosn't exist in current context
            //Dictionary<int, QandAvalues> QandADictionary = new Dictionary<int, QandAvalues>();
            IDictionary<string, string> QandA = new Dictionary<string, string>();
            //
            callnr1.Text = QandA.ElementAt(randNum.Next(0, 10)).Key;//null null here
            callnr2.Text = QandA.ElementAt(randNum.Next(0, 10)).Key;
            callnr3.Text = QandA.ElementAt(randNum.Next(0, 10)).Key;
            callnr4.Text = QandA.ElementAt(randNum.Next(0, 10)).Key;
            //Need to clean up code more
            /*callnr1.Text = (string)QandAvalues.ElementAt(rand.Next(0, QandAvalues.Count)).Value;
            callnr2.Text = (string)QandAvalues.ElementAt(rand.Next(1, QandAvalues.Count)).Value;
            callnr3.Text = (string)QandAvalues.ElementAt(rand.Next(2, QandAvalues.Count)).Value;
            callnr4.Text = (string)QandAvalues.ElementAt(rand.Next(3, QandAvalues.Count)).Value;*/
        }
        public void FillAnswerTextboxes() //Answer textboxes
        {
            //Must allows users to Enter the answers to questions
            a1 = answer1.Text; //This will answer question 1 'a'
            a2 = answer2.Text; //This will answer question 2 'b'
            a3 = answer3.Text; //This will answer question 3 'c'
            a4 = answer4.Text; //This will answer question 4 'd'
        }
        public void FillOptionsTextboxes() //Options textboxes
        {
            //Autofill data with possibles answers from dictionary, Description = Value
            Random randNum = new Random();
            //Dictionary<string, object> QandAvalues = GetDictionary();//dosn't exist in current context
            IDictionary<string, string> QandA = new Dictionary<string, string>();
            description1.Text = QandA.ElementAt(randNum.Next(0, 10)).Value;//null null here
            description2.Text = QandA.ElementAt(randNum.Next(0, 10)).Value;
            description3.Text = QandA.ElementAt(randNum.Next(0, 10)).Value;
            description4.Text = QandA.ElementAt(randNum.Next(0, 10)).Value;
            description5.Text = QandA.ElementAt(randNum.Next(0, 10)).Value;
            description6.Text = QandA.ElementAt(randNum.Next(0, 10)).Value;
            description7.Text = QandA.ElementAt(randNum.Next(0, 10)).Value;
            description8.Text = QandA.ElementAt(randNum.Next(0, 10)).Value;
            description9.Text = QandA.ElementAt(randNum.Next(0, 10)).Value;
            description10.Text = QandA.ElementAt(randNum.Next(0, 10)).Value;
        }
        //previously used to check the users answers
        private void btncheck_Click (object sender, RoutedEventArgs e)//Used to check data entered by user
        {
            //Third Attempt at method, needs further Testing to avoid errors
            string correctAnswer1 = QandA[callnr1.Text];
            string correctAnswer2 = QandA[callnr2.Text];
            string correctAnswer3 = QandA[callnr3.Text];
            string correctAnswer4 = QandA[callnr4.Text];

            bool isCorrect1 = a1 == correctAnswer1; //must rename it from 'userAnswer1' to 'a1'
            bool isCorrect2 = a2 == correctAnswer2; //must rename it from 'userAnswer2' to 'a2'
            bool isCorrect3 = a3 == correctAnswer3; //must rename it from 'userAnswer3' to 'a3'
            bool isCorrect4 = a4 == correctAnswer4; //must rename it from 'userAnswer4' to 'a4'

            // You can use these bool values to display feedback to the user
            if (isCorrect1)
            {
                MessageBox.Show("Answer 1 is correct!");
            }
            else
            {
                MessageBox.Show("Answer 1 is incorrect.");
            }
            if (isCorrect2)
            {
                MessageBox.Show("Answer 2 is correct!");
            }
            else
            {
                MessageBox.Show("Answer 2 is incorrect.");
            }
            if (isCorrect3)
            {
                MessageBox.Show("Answer 3 is correct!");
            }
            else
            {
                MessageBox.Show("Answer 3 is incorrect.");
            }
            //For Answer 4
            if (isCorrect4)
            {
                MessageBox.Show("Answer 4 is correct!");
            }
            else
            {
                MessageBox.Show("Answer 4 is incorrect.");
            }
        }

        private void btntryagain_Click(object sender, RoutedEventArgs e)//Reruns previous methods, resets page basically (need to make it work properly)
        {
            //Meant to clear textboxes before generating them
            callnr1.Clear();
            callnr2.Clear();
            callnr3.Clear();
            callnr4.Clear();
            description1.Clear();
            description2.Clear();
            description3.Clear();
            description4.Clear();
            description5.Clear();
            description6.Clear();
            description7.Clear();
            description8.Clear();
            description9.Clear();
            description10.Clear();
            //
            Random randNum = new Random();
            //Random variables for randomizing the values [1 to 10]
            /*int rand1 = 1;
            int rand2 = 2;
            int rand3 = 3;
            int rand4 = 4;
            int rand5 = 5;
            int rand6 = 6;
            int rand7 = 7;
            int rand8 = 8;
            int rand9 = 9;
            int rand10 = 10;*/
            //Random variables Second attempt [0 to 9]
            int rand1 = 0;
            int rand2 = 1;
            int rand3 = 2;
            int rand4 = 3;
            int rand5 = 4;
            int rand6 = 5;
            int rand7 = 6;
            int rand8 = 7;
            int rand9 = 8;
            int rand10 = 9;
            //IDictionary<string, string> QandA = new Dictionary<string, string>(); //null null here, ensure that the value of the invalid argument is non-negative. 
            /*callnr1.Text = QandA.ElementAt(randNum.Next(0, 10)).Key;
            callnr3.Text = QandA.ElementAt(randNum.Next(0, 10)).Key;
            callnr2.Text = QandA.ElementAt(randNum.Next(0, 10)).Key;
            callnr4.Text = QandA.ElementAt(randNum.Next(0, 10)).Key;*/
            //Proper Logic
            callnr1.Text = QandA.ElementAt(rand1).Key;
            callnr2.Text = QandA.ElementAt(rand2).Key;
            callnr3.Text = QandA.ElementAt(rand3).Key;
            callnr4.Text = QandA.ElementAt(rand4).Key;//*/
            //
            //
            //description1.Text = QandA.ElementAt(randNum.Next(0, 10)).Value;//null null here
            /*description1.Text = QandA.ElementAt(randNum.Next(0, 10)).Value;
            description2.Text = QandA.ElementAt(randNum.Next(0, 10)).Value;
            description3.Text = QandA.ElementAt(randNum.Next(0, 10)).Value;
            description4.Text = QandA.ElementAt(randNum.Next(0, 10)).Value;
            description5.Text = QandA.ElementAt(randNum.Next(0, 10)).Value;
            description6.Text = QandA.ElementAt(randNum.Next(0, 10)).Value;
            description7.Text = QandA.ElementAt(randNum.Next(0, 10)).Value;
            description8.Text = QandA.ElementAt(randNum.Next(0, 10)).Value;
            description9.Text = QandA.ElementAt(randNum.Next(0, 10)).Value;
            description10.Text = QandA.ElementAt(randNum.Next(0, 10)).Value;*/
            //Proper Logic
            description1.Text = QandA.ElementAt(rand1).Value;
            description2.Text = QandA.ElementAt(rand2).Value;
            description3.Text = QandA.ElementAt(rand3).Value;
            description4.Text = QandA.ElementAt(rand4).Value;
            description5.Text = QandA.ElementAt(rand5).Value;
            description6.Text = QandA.ElementAt(rand6).Value;
            description7.Text = QandA.ElementAt(rand7).Value;
            description8.Text = QandA.ElementAt(rand8).Value;
            description9.Text = QandA.ElementAt(rand9).Value;
            description10.Text = QandA.ElementAt(rand10).Value;//*/ 'Specified argument was out of the range of valid values. (Parameter 'index')'
        }
        //Doesn't cuase crashes
        private void btnachieve_Click(object sender, RoutedEventArgs e)
        {
            Achievements achievements = new Achievements();
            this.Hide();
            achievements.Show();
        }
        //Method for 'Check Answer' Button's decision, replaced by popups
        /*private void txtsortstatus2_TextChanged(object sender, TextChangedEventArgs e)
        {
            txtsortstatus2.Text = "INCORRECT";
        }*/
        //new button
        private void btncheckanswers2_Click(object sender, RoutedEventArgs e)
        {
            //Third Attempt at method, needs further Testing to avoid errors
            string correctAnswer1 = QandA[callnr1.Text];
            string correctAnswer2 = QandA[callnr2.Text];
            string correctAnswer3 = QandA[callnr3.Text];
            string correctAnswer4 = QandA[callnr4.Text];

            //bool isCorrect1 = a1 == correctAnswer1; //must rename it from 'userAnswer1' to 'a1'
            bool isCorrect2 = a2 == correctAnswer2; //must rename it from 'userAnswer2' to 'a2'
            bool isCorrect3 = a3 == correctAnswer3; //must rename it from 'userAnswer3' to 'a3'
            bool isCorrect4 = a4 == correctAnswer4; //must rename it from 'userAnswer4' to 'a4'

            // You can use these bool values to display feedback to the user, ( matchColumn[lbMatch.Text] == lbDes.Text)
            //(/*isCorrect2*/ Dic[correctAnswer1/*.Text*/] == a1/*/*Text*/)

            if (/*isCorrect1*/ QandA [callnr1.Text] != a1) //Must compare the index of each value to see if they match, must test
            {
                MessageBox.Show("Answer 1 is incorrect."); //changed 'correct' to 'incorrect'
            }
            else
            {
                MessageBox.Show("Answer 1 is correct!"); //changed 'incorrect' to 'correct'
            }
            if (isCorrect2)
            {
                MessageBox.Show("Answer 2 is correct!");
            }
            else
            {
                MessageBox.Show("Answer 2 is incorrect.");
            }
            if (isCorrect3)
            {
                MessageBox.Show("Answer 3 is correct!");
            }
            else
            {
                MessageBox.Show("Answer 3 is incorrect.");
            }
            //For Answer 4
            if (isCorrect4)
            {
                MessageBox.Show("Answer 4 is correct!");
            }
            else
            {
                MessageBox.Show("Answer 4 is incorrect.");
            }
        }
    }
}
