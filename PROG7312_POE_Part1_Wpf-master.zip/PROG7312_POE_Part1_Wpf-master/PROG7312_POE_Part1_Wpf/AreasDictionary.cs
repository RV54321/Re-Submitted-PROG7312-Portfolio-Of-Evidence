﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//using System.Collections.Generic;
using System.Net.NetworkInformation;
//Dictionary used for 'Indentiying Areas' Page, these values are used in the columns
namespace PROG7312_POE_Part1_Wpf
{
    class Program
    {

        //Dictionary<int, QandAvalues> QandADictionary = new Dictionary<int, QandAvalues>();
        //QandAvalues<int, string> QandADictionary = new QandAvalues<int, string>();
        //IDictionary<string, string> QandA = new Dictionary<string, string>();

        //static void /*Main*/ Dic(/*string[] args*/)
        /*{
            //Method
            IDictionary<string, string> QandA = new Dictionary<string, string>();
            QandA.Add("What is this called 000–099?", "general works"); //adding a key/value using the Add() method
            QandA.Add("What is this called 100–199?", "philosophy and psychology");
            QandA.Add("What is this called 200–299?", "religion");
            QandA.Add("What is this called 300–399?", "social sciences");
            QandA.Add("What is this called 400–499?", "language");
            QandA.Add("What is this called 500–599?", "natural sciences and mathematics");
            QandA.Add("What is this called 600–699?", "technology");
            QandA.Add("What is this called 700–799?", "the arts");
            QandA.Add("What is this called 800–899?", "literature and rhetoric");
            QandA.Add("What is this called 900–999?", "history, biography, and geography");
        }*/
        //Method
        /*IDictionary<string, string> QandA = new Dictionary<string, string>();
        QandA.Add("What is this called 000–099?", "general works"); ; //adding a key/value using the Add() method
        QandA.Add("What is this called 100–199?", "philosophy and psychology");
        QandA.Add("What is this called 200–299?", "religion");
        QandA.Add("What is this called 300–399?", "social sciences");
        QandA.Add("What is this called 400–499?", "language");
        QandA.Add("What is this called 500–599?", "natural sciences and mathematics");
        QandA.Add("What is this called 600–699?", "technology");
        QandA.Add("What is this called 700–799?", "the arts");
        QandA.Add("What is this called 800–899?", "literature and rhetoric");
        QandA.Add("What is this called 900–999?", "history, biography, and geography");*/
        //Method 2
        /*IDictionary<int, string, string> QandA = new Dictionary<int, string, string>();
        QandA.Add(1, "What is this called 000–099?", "general works"); ; //adding a key/value using the Add() method
        QandA.Add(2, "What is this called 100–199?", "philosophy and psychology");
        QandA.Add(3, "What is this called 200–299?", "religion");
        QandA.Add(4, "What is this called 300–399?", "social sciences");
        QandA.Add(5, "What is this called 400–499?", "language");
        QandA.Add(6, "What is this called 500–599?", "natural sciences and mathematics");
        QandA.Add(7, "What is this called 600–699?", "technology");
        QandA.Add(8, "What is this called 700–799?", "the arts");
        QandA.Add(9, "What is this called 800–899?", "literature and rhetoric");
        QandA.Add(10, "What is this called 900–999?", "history, biography, and geography");
        //Method 3
        /*class QandAvalues
        {
            public int Id { get; set; }
            public string Question { get; set; }
            public string Answer { get; set; }
        }
        QandAvalues One = new QandAvalues() { Id = 1, Question = "What is this called 000–099?", Answer = "general works"};
        QandAvalues Two = new QandAvalues() { Id = 2, Question = "What is this called 100–199?", Answer = "philosophy and psychology" };
        QandAvalues Three = new QandAvalues() { Id = 3, Question = "What is this called 200–299?", Answer = "religion" };
        QandAvalues Four = new QandAvalues() { Id = 4, Question = "What is this called 300–399?", Answer = "social sciences" };
        QandAvalues Five = new QandAvalues() { Id = 5, Question = "What is this called 400–499?", Answer = "language" };
        QandAvalues Six = new QandAvalues() { Id = 6, Question = "What is this called 500–599?", Answer = "natural sciences and mathematics" };
        QandAvalues Seven = new QandAvalues() { Id = 7, Question = "What is this called 600–699?", Answer = "technology" };
        QandAvalues Eight = new QandAvalues() { Id = 8, Question = "What is this called 700–799?", Answer = "the arts" };
        QandAvalues Nine = new QandAvalues() { Id = 9, Question = "What is this called 800–899?", Answer = "literature and rhetoric" };
        QandAvalues Ten = new QandAvalues() { Id = 10, Question = "What is this called 900–099?", Answer = "history, biography, and geography" };
        //
        Dictionary<int, QandAvalues> QandADictionary = new Dictionary<int, QandAvalues>();*/
        //QandAvalues<int, string> QandADictionary = new QandAvalues<int, string>();
    }
}
//}
