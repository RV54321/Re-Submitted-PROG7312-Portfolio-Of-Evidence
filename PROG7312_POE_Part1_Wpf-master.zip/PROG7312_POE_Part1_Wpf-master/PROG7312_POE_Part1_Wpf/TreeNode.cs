﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//
namespace PROG7312_POE_Part1_Wpf
{
    /*internal*/ class TreeNode <T>
    {
        public T Data { get; set; }
        public T Description { get; set; }//Added
        public TreeNode<T> Parent { get; set; }
        public List<TreeNode<T>> Children { get; set; }
    }
}
