﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROG7312_POE_Part1_Wpf
{
    class RandomGenerator
    {
        static void RandomMain()//Changed Main to RandomMain
        {
            System.Random random = new System.Random();//Randomizes the call number data
            System.Console.WriteLine(random.Next());
            System.Console.WriteLine(random.Next(50));
            System.Console.WriteLine(random.Next(0, 1000));
        }//*/
    }
}
