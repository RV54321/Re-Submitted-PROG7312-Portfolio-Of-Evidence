﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using static PROG7312_POE_Part1_Wpf.SharedDataClass;

namespace PROG7312_POE_Part1_Wpf
{
    /// <summary>
    /// Interaction logic for Achievements.xaml
    /// </summary>
    public partial class Achievements : Window
    {
        SharedDataClass SharedData = new SharedDataClass();//Turned into global variable
        private bool btncheckanswers2;//Achievement 2: Completed identifying areas page Task

        public Achievements()
        {
            InitializeComponent();
            Achievemnt1();//Achievement 1: Completed Replace Page Task
            txtAchievement1.Text = Achievemnt1();
            Achievemnt2();//Achievement 2: Completed identifying areas page Task
            txtAchievement2.Text = Achievemnt2();
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            this.Hide();
            mainWindow.Show();
        }
        private String Achievemnt1()//Boolean check to see if this was achieved
        {
            if (SharedData.SharedValue == "true")
            {
                return "COMPLETED!";
            }
            else
            {
                return "INCOMPLETE";
            }
        }//
        private String Achievemnt2()//Boolean check to see if this was achieved 'Identifyingareas'
        {
            //private bool btncheckanswers2_Click = false;
            //private bool btncheckanswers2 = false;
            if (btncheckanswers2)
            {
                return "COMPLETED!";
            }
            else
            {
                return "INCOMPLETE";
            }
        }
    }
}
