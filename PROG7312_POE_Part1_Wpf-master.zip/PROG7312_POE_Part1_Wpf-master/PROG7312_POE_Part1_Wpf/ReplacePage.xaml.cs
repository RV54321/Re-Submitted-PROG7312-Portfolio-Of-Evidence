﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Xml.XPath;
//using System.Windows.Forms;
using System.Windows.Threading;
using System.Text.RegularExpressions;
using System.Numerics;
using System.Text;
using System.Xml.Linq;
//
using System.Collections.Generic;

namespace PROG7312_POE_Part1_Wpf
{
    /// <summary>
    /// Interaction logic for ReplacePage.xaml
    /// </summary>
    public partial class ReplacePage : Window
    {
        public ReplacePage()
        {
            InitializeComponent();
            FillTextboxes();
            //GFG gfg = new GFG();//Gonna have to figure this out later
            Node node = new Node();
            //btncheck_Click();
        }
        public void FillTextboxes() //Fills 'Unorganized' textboxes
        {
            //Autofill data
            txtcall1.Text = 10.ToString();
            txtcall2.Text = 9.ToString();
            txtcall3.Text = 8.ToString();
            txtcall4.Text = 7.ToString();
            txtcall5.Text = 6.ToString();
            txtcall6.Text = 5.ToString();
            txtcall7.Text = 4.ToString();
            txtcall8.Text = 3.ToString();
            txtcall9.Text = 2.ToString();
            txtcall10.Text = 1.ToString();
        }
        private void button1_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            this.Hide();
            mainWindow.Show();
        }
        public /*private*/ void btncheck_Click(object sender, RoutedEventArgs e)//Used to check data entered by user
        {/*
            int[] numbers = { int.Parse(txtcorrectcall1.Text) , int.Parse(txtcorrectcall2.Text) , int.Parse(txtcorrectcall3.Text) ,
                            int.Parse(txtcorrectcall4.Text),int.Parse(txtcorrectcall5.Text),int.Parse(txtcorrectcall6.Text),int.Parse(txtcorrectcall7.Text),
                            int.Parse(txtcorrectcall8.Text),int.Parse(txtcorrectcall9.Text),int.Parse(txtcorrectcall10.Text)};

            int[] UserNumbers = { int.Parse(txtcorrectcall1.Text) , int.Parse(txtcorrectcall2.Text) , int.Parse(txtcorrectcall3.Text) ,
                            int.Parse(txtcorrectcall4.Text),int.Parse(txtcorrectcall5.Text),int.Parse(txtcorrectcall6.Text),int.Parse(txtcorrectcall7.Text),
                            int.Parse(txtcorrectcall8.Text),int.Parse(txtcorrectcall9.Text),int.Parse(txtcorrectcall10.Text)};

            SortedArray(numbers);


            txtsortstatus.Text = CheckArray(numbers, UserNumbers);*/
        }

        private void SortedArray(int[] numbers)
        {
            Boolean Sorted = false;

            while (Sorted = false)
            {

                int countif = 0;

                for (int k = 0; k >= 10; k++)
                {
                    if (numbers[k] < numbers[k + 1])
                    {
                        int swap = numbers[k + 1];

                        numbers[k + 1] = numbers[k];
                        numbers[k] = swap;

                        countif = countif + 1;
                    }
                }
                if (countif > 0)
                {
                    Sorted = false;
                }
                else
                {
                    Sorted = true;
                }
            }
        }
        public string CheckArray(int[] numbers, int[] UserNumbers)
        {
            Boolean Sorted = false;

            int countif = 0;

            for (int k = 0; k >= 10; k++)
            {
                if (numbers[k] != UserNumbers[k])
                {
                    countif = countif + 1;
                }
            }
            if (countif > 0)
            {
                return "Unsorted";
            }
            else
            {
                return "Sorted";
            }
        }
        //
        private void btnachieve_Click(object sender, RoutedEventArgs e)//Quickly takes you to 'Achievemnts' Page
        {
            Achievements achievements = new Achievements();
            this.Hide();
            achievements.Show();
        }
    }
}
