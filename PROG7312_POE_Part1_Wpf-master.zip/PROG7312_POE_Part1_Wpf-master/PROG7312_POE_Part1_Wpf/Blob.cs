﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//using static PROG7312_POE_Part1_Wpf.GFG;//added
using static PROG7312_POE_Part1_Wpf.Node;//added

namespace PROG7312_POE_Part1_Wpf
{
    class Blob
    {
        public Node Head;

        public void Add(String data, string id)//changed to string
        {
            if (data == null)
            {
                return;
            }
            else if (data == null)
            {
                Head = new Node(data, id);//
                return;
            }
            else
            {
                Node n = new Node(data, id);//
                Node current = Head;
                while (current.next != null)
                {
                    current = current.next;
                }
                n.prev = current;//changed previous to prev?
                current.next = n;
            }
        }//*/

        internal void Add(int v1, string v2)
        {
            throw new NotImplementedException();
        }
    }
}
