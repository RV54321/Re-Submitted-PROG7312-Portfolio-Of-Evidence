PROG7312 POE Part 2 -  Identifying Areas

Program Details:
1. Design Pattern: Wpf (Windows Presentation Foundation)

Running the Program, inside of Visual Studio:
1.Open up the folder 'PROG7312_POE_Part_1_Wpf', double-click on the 'Microsoft Visual Studio Solution (.sln)' file and then the program will open up inside Visual Studio. 
  Press the run button at the top and the program will begin its operations.

2.'MainWindow', click on the one of the three buttons below 'The Three Tasks' to access the App features.
  Features:
   1)'Replace Books Page'
   2)'Identifying areas Page' [Enabled for Part 2]
   3)'Finding call numbers Page' [Disabled for Part 2]

2.1 'Replace Books Page' 
    This will redirect the User to a seprate page for the purpose of replacing book information.
     *Users will recieve the organised data and will then be allowed to re-organise the data into ascending order.
     *Users will be able to check if thier re-oganisation of data was sucessful or not.

2.2 'Identifying areas Page' [Enabled for Part 2].
    Users will be able to match columns together and have thier answers checked by the program.
    A button will be available to generate the Questions and Answers for them.
    A button will be available to check whether the entered values are correct or not and then indicate this to Users
     *User(s) can answer as many questions as they want to.
     *Questions alternate between matching descriptions to call numbers and call numbers to descriptions.
     *First Column has Four randomly selected items, Second Column has seven possible answers (three are incorrect).

2.3 'Finding call numbers Page' [Disabled for Part 2].

2.4 'Achievments' Page, this allows Users to check what they achieved will working on the App. [Part 1 and 2 Gamification Feature]

3.Use the 'x' button at the top right of the program window to close the application once all the necessary tasks, used to test the program, have been completed.
  All enterd data should still be visible in the created database.